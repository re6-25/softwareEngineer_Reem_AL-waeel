<?php
require_once 'Database.php';
class Order {
    private $db;
    public function __construct() {
        $this->db = (new Database())->conn; // اتصال PDO
    }

    // إضافة طلب جديد
    public function add($data) {
        $stmt = $this->db->prepare("INSERT INTO orders 
            (user_id, books, total, discount, coupon, coupon_discount, shipping, final, note, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $books_json = json_encode($data['books']);
        return $stmt->execute([
            $data['user_id'],
            $books_json,
            $data['total'],
            $data['discount'],
            $data['coupon'],
            $data['coupon_discount'],
            $data['shipping'],
            $data['final'],
            $data['note'],
            $data['created_at']
        ]);
    }
}
?>
